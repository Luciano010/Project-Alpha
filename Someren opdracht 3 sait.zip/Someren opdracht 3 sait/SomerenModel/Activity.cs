﻿using System;

namespace SomerenModel
{
    public class Activity
    {
        public string activityName { get; set; }
        public DateTime startTime { get; set; } 
        public DateTime endTime { get; set; }
    }
}
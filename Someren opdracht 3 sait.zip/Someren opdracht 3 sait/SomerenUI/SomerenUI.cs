using SomerenService;
using SomerenModel;
using System.Windows.Forms;
using System.Collections.Generic;
using System;
using System.Data.SqlClient;
using System.Configuration;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        public SomerenUI()
        {
            InitializeComponent();
        }

        private void ShowDashboardPanel()
        {
            // hide all other panels
            pnlStudents.Hide();

            // show dashboard
            pnlDashboard.Show();

            pnlActivities.Hide();

            pnlDashboard.Show();

        }

        private void ShowStudentsPanel()
        {
            // hide all other panels
            pnlDashboard.Hide();

            // show students
            pnlStudents.Show();



            try
            {
                // get and display all students
                List<Student> students = GetStudents();
                DisplayStudents(students);
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the students: " + e.Message);
            }
        }

        private List<Student> GetStudents()
        {
            StudentService studentService = new StudentService();
            List<Student> students = studentService.GetStudents();
            return students;
        }

        private void DisplayStudents(List<Student> students)
        {
            // clear the listview before filling it
            listViewActivities.Clear();

            foreach (Student student in students)
            {
                ListViewItem li = new ListViewItem(student.Name);
                li.Tag = student;   // link student object to listview item
                listViewActivities.Items.Add(li);
            }
        }

        private void dashboardToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            ShowDashboardPanel();
        }

        private void exitToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStudentsPanel();
        }

        private void ShowActivitiesPanel()
        {
            // hide all other panels
            pnlDashboard.Hide();

            // show activities
            pnlActivities.Show();

            try
            {
                // get and display all activities
                List<Activity> activities = GetActivities();
                DisplayActivities(activities);
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the activities: " + e.Message);
            }
        }

        private List<Activity> GetActivities()
        {
            ActivityService activityService = new ActivityService();
            List<Activity> activities = activityService.GetActivities();
            return activities;
        }

        private void DisplayActivities(List<Activity> activities)
        {
            listViewActivities.Clear();

            foreach (Activity activity in activities)
            {
                ListViewItem li = new ListViewItem(activity.activityName);
                li.SubItems.Add(activity.startTime.ToString());
                li.SubItems.Add(activity.endTime.ToString());
                li.Tag = activity;
                listViewActivities.Items.Add(li);
            }

            listViewActivities.View = View.Details;
        }

        private void activitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowActivitiesPanel();
        }

        private void omzetrapportageButton_Click(object sender, EventArgs e)
        {
            // werkt bij bardienst en dan klik je op omzetrapportage
            DateTime startDate = startDateButton.SelectionRange.Start;
            DateTime endDate = endDateButton.SelectionRange.End;

            if (startDate > endDate || endDate > DateTime.Today)
            {
                MessageBox.Show("Invalid date selected.");
                return;
            }

            string query = "SELECT COUNT(*) AS Sales, SUM(Price * Quantity) AS Turnover, COUNT(DISTINCT StudentID) AS Customers " +
                           "FROM Activity " +
                           "WHERE SaleDate BETWEEN @startDate AND @endDate";
            string connectionString = ConfigurationManager.ConnectionStrings["SomerenDatabase"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@startDate", startDate);
                    command.Parameters.AddWithValue("@endDate", endDate);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        int sales = reader.GetInt32(0);
                        decimal turnover = reader.GetDecimal(1);
                        int customers = reader.GetInt32(2);

                        listViewActivities.Items.Clear();
                        ListViewItem item1 = new ListViewItem("Sales");
                        item1.SubItems.Add(sales.ToString());
                        ListViewItem item2 = new ListViewItem("Turnover");
                        item2.SubItems.Add(turnover.ToString("C"));
                        ListViewItem item3 = new ListViewItem("Customers");
                        item3.SubItems.Add(customers.ToString());
                        listViewActivities.Items.AddRange(new ListViewItem[] { item1, item2, item3 });
                    }
                    reader.Close();
                }
            }
        }
    }
}
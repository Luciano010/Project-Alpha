﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System;
using SomerenModel;

namespace SomerenDAL
{
    public class ActivityDao : BaseDao
    {
        public List<Activity> GetAllActivities()
        {
            string query = "SELECT activityName, startTime, endTime FROM [TABLE]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Activity> ReadTables(DataTable dataTable)
        {
            List<Activity> activities = new List<Activity>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Activity activity = new Activity()
                {
                    activityName = dr["activityName"].ToString(),
                    startTime = (DateTime)dr["startTime"],
                    endTime = (DateTime)dr["endTime"]
                };
                activities.Add(activity);
            }
            return activities;
        }
    }
}
using SomerenService;
using SomerenModel;
using System.Windows.Forms;
using System.Collections.Generic;
using System;
using System.ComponentModel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        public SomerenUI()
        {
            InitializeComponent();
        }

        private void ShowDashboardPanel()
        {
            // hide all other panels
            pnlStudents.Hide();

            // show dashboard
            pnlDashboard.Show();
        }

        //STUDENTS
        private void ShowStudentsPanel()
        {
            // hide all other panels
            pnlDashboard.Hide();
            pnlDrinks.Hide();

            // show students
            pnlStudents.Show();

            try
            {
                // get and display all students
                List<Student> students = GetStudents();
                DisplayStudents(students);
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the students: " + e.Message);
            }
        }

        private List<Student> GetStudents()
        {
            StudentService studentService = new StudentService();
            List<Student> students = studentService.GetStudents();
            return students;
        }

        private void DisplayStudents(List<Student> students)
        {
            studentDataGridView.DataSource = students;
        }

        //DRINK SUPPLIES
        private void ShowDrinksPanel()
        {
            // hide all other panels
            pnlDashboard.Hide();
            pnlStudents.Hide();

            // show students
            pnlDrinks.Show();

            try
            {
                // get and display all students
                List<Drink> drinks = GetDrinks();
                DisplayDrinks(drinks);
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the drinks: " + e.Message);
            }
        }

        private List<Drink> GetDrinks()
        {
            DrinkService drinkService = new DrinkService();
            List<Drink> drinks = drinkService.GetDrinks();
            return drinks;
        }

        private void DisplayDrinks(List<Drink> drinks)
        {
            listViewDrinks.Clear();

            foreach (Drink drink in drinks)
            {
                ListViewItem item = new ListViewItem(drink.drinkName);
                item.Tag = drink;
                listViewDrinks.Items.Add(item);

                ListViewItem price = new ListViewItem(drink.price.ToString());
                price.Tag = drink;
                listViewDrinks.Items.Add(price);

                ListViewItem stock = new ListViewItem(drink.stock.ToString());
                stock.Tag = drink;
                listViewDrinks.Items.Add(stock);

                ListViewItem isAlcoholic = new ListViewItem(drink.isAlcoholic.ToString());
                isAlcoholic.Tag = drink;
                listViewDrinks.Items.Add(isAlcoholic);
            }
        }

        //ACTIVITIES
        private void ShowActivitiesPanel()
        {
            // hide all other panels
            pnlDashboard.Hide();
            pnlStudents.Hide();
            pnlDrinks.Hide();

            // show students
            pnlActivities.Show();


            try
            {
                // get and display all students
                List<SomerenModel.Activity> activities = GetActivities();
                DisplayActivities(activities);
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the activities: " + e.Message);
            }
        }

        private List<SomerenModel.Activity> GetActivities()
        {
            ActivityService activityService = new ActivityService();
            List<SomerenModel.Activity> activities = activityService.GetActivities();
            return activities;
        }

        private void DisplayActivities(List<SomerenModel.Activity> activities)
        {
            listViewActivities.Clear();

            foreach (SomerenModel.Activity activity in activities)
            {

                ListViewItem activityName = new ListViewItem(activity.activityName);
                activityName.Tag = activity;
                listViewActivities.Items.Add(activityName);

                ListViewItem startTime = new ListViewItem(activity.startTime.ToString());
                startTime.Tag = activity;
                listViewActivities.Items.Add(startTime);

                ListViewItem finishTime = new ListViewItem(activity.finishTime.ToString());
                finishTime.Tag = activity;
                listViewActivities.Items.Add(finishTime);
            }
        }

        private void dashboardToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            ShowDashboardPanel();
        }

        private void exitToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStudentsPanel();
            this.label1.Text = "Students";
        }

        private void drankvoorraadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDrinksPanel();
            this.label1.Text = "Drinks";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listViewDrinks.SelectedItems.Count == 0)
                return;

            Drink drink = (Drink)listViewDrinks.SelectedItems[0].Tag;

            if (InputTextBoxDrinkName.Text != "")
            {
                listViewDrinks.SelectedItems[0].Text = InputTextBoxDrinkName.Text;
            }
            else if (InputTextBoxPrice.Text != "")
            {
                listViewDrinks.SelectedItems[0].Text = InputTextBoxPrice.Text;
            }
            else if (InputTextBoxStock.Text != "")
            {
                listViewDrinks.SelectedItems[0].Text = InputTextBoxStock.Text;
            }
        }

        private void activitiesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ShowActivitiesPanel();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listViewActivities.SelectedItems.Count == 0)
                return;

            SomerenModel.Activity activity = (SomerenModel.Activity)listViewActivities.SelectedItems[0].Tag;

            if (InputTextBoxStartTime.Text == "" && InputTextBoxActivityName.Text != "")
            {
                listViewActivities.SelectedItems[0].Text = InputTextBoxActivityName.Text;
            }
            else
            {
                listViewActivities.SelectedItems[0].Text = InputTextBoxFinishTime.Text;
            }
        }

        //REMOVE 
        private void button4_Click(object sender, EventArgs e)
        {
            listViewActivities.Items.Remove(listViewActivities.SelectedItems[0]);
        }

        //ADD
        private void button3_Click(object sender, EventArgs e)
        {
            SomerenModel.Activity activity = new SomerenModel.Activity(); 

            ListViewItem item1 = new ListViewItem(InputTextBoxActivityName.Text);
            item1.Tag = activity;
            listViewActivities.Items.Add(item1);

            ListViewItem item2 = new ListViewItem(InputTextBoxStartTime.Text);
            item2.Tag = activity;
            listViewActivities.Items.Add(item2);

            ListViewItem item3 = new ListViewItem(InputTextBoxFinishTime.Text);
            item3.Tag = activity;
            listViewActivities.Items.Add(item3);
        }
    }
}
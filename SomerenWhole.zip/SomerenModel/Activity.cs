﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Activity
    {
        public int activityId { get; set; }
        public DateTime startTime { get; set; }
        public DateTime finishTime { get; set; }
        public string activityName { get; set; }
    }
}
